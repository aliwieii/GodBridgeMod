package com.godbridge.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = GodBridgeClient.MODID, name = GodBridgeClient.NAME, version = GodBridgeClient.VERSION, clientSideOnly = true)
public class GodBridgeClient {
    public static final String MODID = "godbridgeclient";
    public static final String NAME = "God Bridge Client Ultra";
    public static final String VERSION = "0.1.0";
    private final Minecraft mc = Minecraft.getMinecraft();
    private KeyBinding toggleHud;
    private boolean hudEnabled = true;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        toggleHud = new KeyBinding("Toggle God Bridge HUD", Keyboard.KEY_H, "God Bridge Client Ultra");
        ClientRegistry.registerKeyBinding(toggleHud);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (toggleHud != null && toggleHud.isPressed()) hudEnabled = !hudEnabled;
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Text event) {
        if (!hudEnabled || mc.thePlayer == null || mc.theWorld == null) return;
        int x = 7, y = 7;
        Gui.drawRect(x - 4, y - 4, x + 158, y + 51, 0x900B1220);
        mc.fontRendererObj.drawStringWithShadow("§bGOD BRIDGE §fULTRA §7v" + VERSION, x, y, 0xFFFFFF); y += 13;
        mc.fontRendererObj.drawStringWithShadow("§fFPS: §a" + Minecraft.getDebugFPS(), x, y, 0xFFFFFF); y += 11;
        mc.fontRendererObj.drawStringWithShadow("§fXYZ: §e" + (int) mc.thePlayer.posX + " " + (int) mc.thePlayer.posY + " " + (int) mc.thePlayer.posZ, x, y, 0xFFFFFF); y += 11;
        mc.fontRendererObj.drawStringWithShadow("§7HUD: press H to toggle", x, y, 0xFFFFFF);
    }
}
