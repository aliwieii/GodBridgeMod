# God Bridge Client Ultra — source project

Target: Minecraft Java 1.8.9 + Forge 11.15.1.2318, Java 8.

## Current features
- Lightweight on-screen HUD showing FPS and integer XYZ coordinates.
- Press **H** to show/hide the HUD.

## Important status
This is a source project, not a prebuilt or tested JAR. The current execution environment did not have Gradle or Java 8 available, so a local Forge build could not be verified. Do not place this ZIP in `.minecraft/mods`.

## Build a JAR
The included GitHub Actions workflow can build the project in a Java 8 / Gradle 2.14.1 environment. Upload this project to a GitHub repository, then open **Actions → Build God Bridge Client Ultra → Run workflow**. Download the artifact named `GodBridgeClientUltra-Forge-1.8.9`. Only use the resulting JAR if the workflow completes successfully.

## Install
Put the built JAR in `.minecraft/mods` for a matching Minecraft 1.8.9 Forge installation. This mod is only a basic HUD foundation; it does not yet include auto-clicking, automatic block placement, or other advanced features.
